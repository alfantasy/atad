-- Copyright (c) MonetLoader, 2024
-- Built-in library: monetloader
-- Lua package is distributed under the MIT license

local touch_events = {
  POP = 1,
  PUSH = 2,
  MOVE = 3
}

return {
  touch_events = touch_events
}